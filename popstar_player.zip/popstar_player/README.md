# Popstar — плеер с живым текстом

Что делает: просит доступ к музыке на телефоне, играет треки, сам находит синхронный текст
(рядом лежит `.lrc` → берёт его, иначе ищет в базе LRCLIB), подсвечивает слова по ходу песни,
«любовные» слова — красным. Карточка «Любовь» реагирует на строки текста, «Слава» растёт по ходу трека.

## Как получить APK (без установки чего-либо на компьютер)
1. Зарегистрируйся на github.com → **New repository** (любое имя, Public или Private).
2. Загрузи ВСЕ файлы из этого архива: **Add file → Upload files**.
   Важно, чтобы загрузилась скрытая папка `.github/workflows/build.yml`.
   Если её нет — **Add file → Create new file**, имя `.github/workflows/build.yml`, вставь содержимое файла.
3. Вкладка **Actions** → слева **Build APK** → справа **Run workflow** (или он стартует сам после загрузки).
4. Через ~5–8 минут открой завершённый запуск → внизу **Artifacts → popstar-apk** → скачай zip → внутри `app-release.apk`.
5. Скинь apk на телефон и установи (разреши «установку из неизвестных источников»).

## Если хочешь собирать сам
Поставь Flutter + Android Studio, затем в папке проекта:
```
flutter create --platforms=android --org com.popstar --project-name popstar_player .
```
Добавь в `android/app/src/main/AndroidManifest.xml` перед `<application`:
```
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.READ_MEDIA_AUDIO"/>
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>
```
И `flutter build apk --release`.

## Оффлайн-распознавание текста (Whisper)
Если готового текста нет (ни `.lrc`, ни в базе LRCLIB), телефон сам распознаёт слова из песни
моделью Whisper base (~142 МБ, английский + русский). Модель скачивается ОДИН раз при первом распознавании
(нужен интернет), дальше всё работает без сети. Результат сохраняется — каждая песня распознаётся один раз.
Кнопка «⋯» → «Распознать тексты всех песен» обработает всю папку в фоне. Язык можно выбрать там же.
Сборка APK с Whisper идёт дольше (10–15 минут).
