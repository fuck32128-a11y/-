#!/usr/bin/env bash
# Правит сгенерированный Android-проект: разрешения, minSdk, compileSdk.
# Запускается из GitHub Actions; менять можно прямо в этом архиве.
set -e
cd "$(dirname "$0")/.."

python3 - <<'PY'
p = 'android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()
perms = (
    '<uses-permission android:name="android.permission.INTERNET"/>\n'
    '    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO"/>\n'
    '    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>\n'
    '    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE"/>\n'
    '    <uses-permission android:name="android.permission.WAKE_LOCK"/>\n'
    '    '
)
s = s.replace('<application', perms + '<application', 1)
s = s.replace('android:label="popstar_player"', 'android:label="Popstar"')
open(p, 'w', encoding='utf-8').write(s)
PY

# ffmpeg и whisper требуют Android 7+
grep -rl "flutter.minSdkVersion" android/app | xargs sed -i 's/flutter\.minSdkVersion/24/g'

# все плагины собираем под compileSdk 36
cd android
if [ -f settings.gradle.kts ]; then
cat >> settings.gradle.kts <<'KTS'

gradle.afterProject {
    val ext = this.extensions.findByName("android")
    if (ext != null) {
        try {
            ext.javaClass.getMethod("compileSdkVersion", Int::class.javaPrimitiveType).invoke(ext, 36)
        } catch (e: Exception) {
            println("compileSdk override failed for ${this.name}: $e")
        }
    }
}
KTS
else
cat >> settings.gradle <<'GRV'

gradle.afterProject { p ->
    def ext = p.extensions.findByName('android')
    if (ext != null) { ext.compileSdkVersion 36 }
}
GRV
fi
echo "patched android project"
