import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' show ImageFilter;

import 'package:audio_metadata_reader/audio_metadata_reader.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'package:whisper_ggml_plus/whisper_ggml_plus.dart';
import 'package:whisper_ggml_plus_ffmpeg/whisper_ggml_plus_ffmpeg.dart';

// ───────────────────────── Цвета и утилиты ─────────────────────────

const kBg = Color(0xFF0B0B0D);
const kRed = Color(0xFFFF4D5E);

Color wa(double o) => Colors.white.withAlpha((o * 255).round());
Color ca(Color c, double o) => c.withAlpha((o * 255).round());

String _p2(int v) => v.toString().padLeft(2, '0');
String fmt(Duration d) => '${d.inMinutes}:${_p2(d.inSeconds % 60)}';
String fmtHms(Duration d) =>
    '${_p2(d.inHours)}:${_p2(d.inMinutes % 60)}:${_p2(d.inSeconds % 60)}';

String groupNum(int n) {
  final s = n.toString();
  final b = StringBuffer();
  for (int i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write(' ');
    b.write(s[i]);
  }
  return b.toString();
}

int stableHash(String s) {
  int h = 7;
  for (final c in s.codeUnits) {
    h = (h * 31 + c) & 0x7fffffff;
  }
  return h;
}

// ───────────────────────── Модели ─────────────────────────

const _exts = [
  '.mp3', '.m4a', '.flac', '.wav', '.ogg', '.opus', '.aac', '.wma',
  '.m4b', '.amr', '.mka', '.oga', '.weba',
];
// Короткие файлы (голосовые, звуки) в библиотеку не берём
const _minBytes = 500 * 1024;
const _skipDirs = {'android', 'ringtones', 'notifications', 'alarms'};

class Track {
  final String path;
  String title;
  String artist;
  String album;
  Duration? duration;
  Uint8List? cover;
  bool loaded = false;

  Track(this.path, {required this.title, required this.artist, this.album = ''});

  factory Track.fromPath(String path) {
    final name = path.split('/').last;
    final base =
        name.contains('.') ? name.substring(0, name.lastIndexOf('.')) : name;
    final parts = base.split(' - ');
    if (parts.length >= 2) {
      return Track(path,
          title: parts.sublist(1).join(' - ').trim(), artist: parts.first.trim());
    }
    return Track(path, title: base.trim(), artist: 'Неизвестный исполнитель');
  }

  bool get artistKnown => artist != 'Неизвестный исполнитель';

  /// Название-мусор вроде «12345» или «track01»: искать такой текст в базе нельзя
  bool get nameUseless {
    if (artistKnown) return false;
    final letters = title.replaceAll(RegExp(r'[^\p{L}]', unicode: true), '');
    return letters.length < 4 || RegExp(r'^(track|audio|record|untitled|unknown|new ?recording)', caseSensitive: false).hasMatch(title);
  }

  Future<void> loadMeta() async {
    if (loaded) return;
    loaded = true;
    try {
      final m = await Future.sync(() => readMetadata(File(path), getImage: true));
      if ((m.title ?? '').trim().isNotEmpty) title = m.title!.trim();
      if ((m.artist ?? '').trim().isNotEmpty) artist = m.artist!.trim();
      album = (m.album ?? '').trim();
      duration = m.duration;
      if (m.pictures.isNotEmpty) cover = m.pictures.first.bytes;
    } catch (_) {}
  }
}

class LyricLine {
  final Duration time;
  final String text;
  final List<String> words;
  final List<bool> keys; // «ключевые» слова про любовь — подсвечиваются красным
  final double love; // 0..1
  final String label;
  LyricLine(this.time, this.text, this.words, this.keys, this.love, this.label);
}

// ───────────────────────── Разбор текста песни ─────────────────────────

// Слова-«любовь». Совпадение по началу слова.
const _loveStems = <String, double>{
  'любов': 1.0, 'люблю': 1.0, 'любим': 0.9, 'любил': 0.9, 'влюбл': 1.2,
  'сердц': 0.8, 'поцел': 1.0, 'обним': 0.9, 'нежн': 0.7, 'страст': 0.8,
  'навсегда': 0.7, 'вечн': 0.5, 'глаз': 0.4, 'сияни': 0.5, 'ангел': 0.5,
  'мечт': 0.4, 'роз': 0.3, 'звезд': 0.4, 'небес': 0.4, 'душ': 0.4,
  'мила': 0.6, 'милы': 0.6, 'детка': 0.5, 'малыш': 0.5, 'скуча': 0.6,
  'тоск': 0.5, 'рядом': 0.4, 'вместе': 0.4, 'губ': 0.5, 'тепл': 0.4,
  'love': 1.0, 'lover': 1.0, 'heart': 0.8, 'kiss': 1.0, 'baby': 0.5,
  'babe': 0.5, 'darling': 0.7, 'forever': 0.7, 'angel': 0.5, 'eyes': 0.4,
  'dream': 0.4, 'soul': 0.4, 'desire': 0.7, 'beautiful': 0.4, 'honey': 0.5,
  'together': 0.4, 'lips': 0.5, 'touch': 0.4,
};

final _nonLetter = RegExp(r'[^\p{L}]', unicode: true);
final _edgeJunk = RegExp(r'^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$', unicode: true);

double _wordLove(String w) {
  final n = w.toLowerCase().replaceAll(_nonLetter, '');
  if (n.length < 3) return 0;
  for (final e in _loveStems.entries) {
    if (n.startsWith(e.key)) return e.value;
  }
  return 0;
}

String _cap(String s) =>
    s.isEmpty ? s : s[0].toUpperCase() + s.substring(1);

final _tagRe = RegExp(r'\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]');
final _wordTagRe = RegExp(r'<\d{1,3}:\d{1,2}(?:[.:]\d{1,3})?>');

List<LyricLine> parseLrc(String raw) {
  final times = <Duration>[];
  final texts = <String>[];
  for (final rawLine in const LineSplitter().convert(raw)) {
    final tags = _tagRe.allMatches(rawLine).toList();
    if (tags.isEmpty) continue;
    final text =
        rawLine.substring(tags.last.end).replaceAll(_wordTagRe, '').trim();
    for (final t in tags) {
      final mm = int.parse(t.group(1)!);
      final ss = int.parse(t.group(2)!);
      final frac = t.group(3);
      int ms = 0;
      if (frac != null) ms = int.parse(frac.padRight(3, '0').substring(0, 3));
      times.add(Duration(milliseconds: (mm * 60 + ss) * 1000 + ms));
      texts.add(text);
    }
  }
  final order = List<int>.generate(times.length, (i) => i)
    ..sort((a, b) => times[a].compareTo(times[b]));

  // сколько раз строка повторяется (припев)
  final counts = <String, int>{};
  for (final i in order) {
    final k = texts[i].toLowerCase();
    counts[k] = (counts[k] ?? 0) + 1;
  }

  final out = <LyricLine>[];
  for (final i in order) {
    final text = texts[i];
    final words = text.isEmpty
        ? <String>['♪']
        : text.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    final keys = <bool>[];
    double sum = 0;
    String? hit;
    double best = 0;
    for (final w in words) {
      final lv = text.isEmpty ? 0.0 : _wordLove(w);
      keys.add(lv > 0.35);
      sum += lv;
      if (lv > best) {
        best = lv;
        hit = w.replaceAll(_edgeJunk, '');
      }
    }
    final base = 0.03 + (stableHash(text) % 3) / 100.0;
    double love = base + (sum / 1.4).clamp(0.0, 1.0).toDouble() * (1 - base);
    if (sum > 0 && (counts[text.toLowerCase()] ?? 0) >= 2) love += 0.15;
    love = love.clamp(0.0, 1.0).toDouble();

    String label;
    if (text.isEmpty) {
      label = 'Музыка';
    } else if (hit != null && hit.isNotEmpty) {
      label = _cap(hit);
    } else {
      label = _cap(words
          .take(2)
          .map((w) => w.replaceAll(_edgeJunk, ''))
          .where((w) => w.isNotEmpty)
          .join(' '));
    }
    if (label.length > 20) label = '${label.substring(0, 19)}…';
    out.add(LyricLine(times[i], text, words, keys, love, label));
  }
  return out;
}

String pseudoLrc(String plain, int durSec) {
  final lines =
      plain.split('\n').map((l) => l.trim()).where((l) => l.isNotEmpty).toList();
  if (lines.isEmpty) return '';
  final start = durSec * 0.05;
  final step = durSec * 0.9 / lines.length;
  final b = StringBuffer();
  for (int i = 0; i < lines.length; i++) {
    final t = start + step * i;
    final m = t ~/ 60;
    final s = (t % 60).toStringAsFixed(2).padLeft(5, '0');
    b.writeln('[${_p2(m)}:$s]${lines[i]}');
  }
  return b.toString();
}

// ───────────────────────── Контроллер плеера ─────────────────────────

class PlayerController extends ChangeNotifier {
  final AudioPlayer player = AudioPlayer();
  SharedPreferences? prefs;

  List<Track> tracks = [];
  int index = -1;
  String? folder;
  Set<String> favs = {};

  List<LyricLine> lyrics = [];
  bool lyricsLoading = false;
  String lyricsStatus = '';

  bool playing = false;
  Duration duration = Duration.zero;

  final ValueNotifier<Duration> pos = ValueNotifier(Duration.zero);
  final ValueNotifier<int> line = ValueNotifier(-1);
  final ValueNotifier<double> love = ValueNotifier(0.04);

  StreamSubscription? _s1, _s2, _s3;
  bool _advancing = false;

  // ── распознавание текста на телефоне (Whisper) ──
  final WhisperController _wc = WhisperController();
  Future<void> _lock = Future.value();
  String whisperLang = 'auto'; // auto | en | ru
  String whisperModel = 'base'; // base | small
  Duration offset = Duration.zero; // сдвиг текста относительно песни
  bool batchRunning = false;
  int batchDone = 0, batchTotal = 0;
  String batchError = '';

  Track? get current => (index >= 0 && index < tracks.length) ? tracks[index] : null;

  Future<void> init() async {
    prefs = await SharedPreferences.getInstance();
    favs = (prefs!.getStringList('favs') ?? <String>[]).toSet();
    folder = prefs!.getString('folder');
    whisperLang = prefs!.getString('wlang') ?? 'auto';
    whisperModel = prefs!.getString('wmodel') ?? 'base';

    _s1 = player
        .createPositionStream(
            minPeriod: const Duration(milliseconds: 50),
            maxPeriod: const Duration(milliseconds: 100))
        .listen((p) {
      pos.value = p;
      _updateLine(p);
    });
    _s2 = player.durationStream.listen((d) {
      duration = d ?? Duration.zero;
      notifyListeners();
    });
    _s3 = player.playerStateStream.listen((s) {
      playing = s.playing;
      if (s.processingState == ProcessingState.completed && !_advancing) {
        _advancing = true;
        next().whenComplete(() => _advancing = false);
      }
      notifyListeners();
    });
  }

  // ── доступ к памяти ──

  Future<bool> hasPermission() async {
    if (!Platform.isAndroid) return true;
    return (await Permission.manageExternalStorage.isGranted) ||
        (await Permission.storage.isGranted) ||
        (await Permission.audio.isGranted);
  }

  Future<bool> ensurePermission() async {
    if (!Platform.isAndroid) return true;
    var ok = (await Permission.storage.request()).isGranted; // Android ≤ 12
    if (!ok) ok = (await Permission.audio.request()).isGranted; // Android 13+
    // «Доступ ко всем файлам» (Android 11+): без него часть музыки не видна
    try {
      if (!await Permission.manageExternalStorage.isGranted) {
        await Permission.manageExternalStorage.request();
      }
    } catch (_) {}
    return ok || await Permission.manageExternalStorage.isGranted;
  }

  // ── библиотека ──

  Future<void> _walk(Directory d, List<Track> out, Set<String> seen) async {
    try {
      await for (final e in d.list(followLinks: false)) {
        final name = e.path.split('/').last;
        if (e is Directory) {
          if (name.startsWith('.') || _skipDirs.contains(name.toLowerCase())) {
            continue;
          }
          await _walk(e, out, seen);
        } else if (e is File) {
          final low = e.path.toLowerCase();
          if (!_exts.any(low.endsWith) || seen.contains(e.path)) continue;
          try {
            if (await e.length() < _minBytes) continue;
          } catch (_) {}
          seen.add(e.path);
          out.add(Track.fromPath(e.path));
        }
      }
    } catch (_) {
      // папка недоступна — идём дальше
    }
  }

  void _setTracks(List<Track> found) {
    found.sort((a, b) => a.path.toLowerCase().compareTo(b.path.toLowerCase()));
    final curPath = current?.path;
    tracks = found;
    index = curPath == null ? -1 : tracks.indexWhere((t) => t.path == curPath);
    notifyListeners();
  }

  Future<void> scanFolder(String path) async {
    final found = <Track>[];
    await _walk(Directory(path), found, <String>{});
    folder = path;
    prefs?.setString('folder', path);
    _setTracks(found);
  }

  /// Вся память телефона (и SD-карта): ищем музыку везде
  Future<void> scanAll() async {
    final roots = <String>['/storage/emulated/0'];
    try {
      await for (final e in Directory('/storage').list(followLinks: false)) {
        final n = e.path.split('/').last;
        if (e is Directory && n != 'emulated' && n != 'self') roots.add(e.path);
      }
    } catch (_) {}
    final found = <Track>[];
    final seen = <String>{};
    for (final r in roots) {
      await _walk(Directory(r), found, seen);
    }
    folder = roots.first;
    prefs?.setString('folder', roots.first);
    _setTracks(found);
  }

  void setFiles(List<String> paths) {
    tracks = paths.map(Track.fromPath).toList();
    notifyListeners();
  }

  // ── воспроизведение ──

  Future<void> play(int i) async {
    if (i < 0 || i >= tracks.length) return;
    index = i;
    lyrics = [];
    lyricsLoading = true;
    lyricsStatus = '';
    line.value = -1;
    love.value = 0.04;
    pos.value = Duration.zero;
    notifyListeners();

    final t = tracks[i];
    offset = Duration(milliseconds: prefs?.getInt('off:${t.path}') ?? 0);
    try {
      await player.setFilePath(t.path);
      player.play();
    } catch (_) {
      lyricsLoading = false;
      lyricsStatus = 'Не удалось открыть файл';
      notifyListeners();
      return;
    }
    await t.loadMeta();
    _applyCustom(t);
    if (index != i) return;
    notifyListeners();
    await _loadLyrics(t, i);
  }

  Future<void> next() async {
    if (tracks.isEmpty) return;
    await play((index + 1) % tracks.length);
  }

  Future<void> prev() async {
    if (tracks.isEmpty) return;
    if (pos.value.inSeconds > 3) {
      await player.seek(Duration.zero);
      return;
    }
    await play((index - 1 + tracks.length) % tracks.length);
  }

  Future<void> togglePlay() async {
    if (player.playing) {
      await player.pause();
    } else {
      player.play();
    }
  }

  void toggleFav() {
    final t = current;
    if (t == null) return;
    if (!favs.remove(t.path)) favs.add(t.path);
    prefs?.setStringList('favs', favs.toList());
    notifyListeners();
  }

  // ── тексты ──

  Future<void> reloadLyrics({bool onlyWhisper = false}) async {
    final t = current;
    if (t == null) return;
    prefs?.remove('lrc:${t.artist}|${t.title}');
    prefs?.remove('edit:${t.path}');
    lyrics = [];
    lyricsLoading = true;
    lyricsStatus = '';
    line.value = -1;
    notifyListeners();
    await _loadLyrics(t, index,
        skipLocal: false, skipCache: true, onlyWhisper: onlyWhisper);
  }

  Future<void> _loadLyrics(Track t, int i,
      {bool skipLocal = false,
      bool skipCache = false,
      bool onlyWhisper = false}) async {
    String? lrc;
    batchError = '';
    final key = 'lrc:${t.artist}|${t.title}';

    // 0) твои правки
    if (!onlyWhisper) lrc = prefs?.getString('edit:${t.path}');
    // 1) .lrc рядом с песней
    if (!onlyWhisper && lrc == null && !skipLocal) {
      try {
        final dot = t.path.lastIndexOf('.');
        if (dot > 0) {
          final f = File('${t.path.substring(0, dot)}.lrc');
          if (await f.exists()) lrc = await f.readAsString();
        }
      } catch (_) {}
    }
    // 2) кэш
    if (!onlyWhisper && lrc == null && !skipCache) lrc = prefs?.getString(key);
    // 3) интернет (LRCLIB — бесплатная база синхронных текстов)
    if (!onlyWhisper && (lrc == null || lrc.trim().isEmpty) && !t.nameUseless) {
      lrc = await _fetchLrclib(t);
      if (lrc != null && lrc.isNotEmpty) prefs?.setString(key, lrc);
    }
    // 4) оффлайн: телефон сам «слушает» песню (Whisper)
    if ((lrc == null || lrc.trim().isEmpty) && index == i) {
      lyricsStatus = 'Распознаю текст на телефоне…\nПервый раз скачается модель, потом всё оффлайн.\nОдна песня — примерно 1–3 минуты.';
      notifyListeners();
      lrc = await _whisperLrc(t);
      if (lrc != null && lrc.isNotEmpty) prefs?.setString(key, lrc);
    }
    if (index != i) return;

    if (lrc != null && lrc.trim().isNotEmpty) {
      lyrics = parseLrc(lrc);
      lyricsStatus = lyrics.isEmpty ? 'Текст найден, но без синхронизации' : '';
    } else {
      lyricsStatus = batchError.isNotEmpty
          ? 'Не удалось распознать текст.\n$batchError'
          : 'Текст не найден.';
    }
    lyricsLoading = false;
    line.value = -1;
    love.value = 0.04;
    _updateLine(pos.value);
    notifyListeners();
  }

  Future<T> _exclusive<T>(Future<T> Function() f) {
    final run = _lock.then((_) => f());
    _lock = run.then((_) {}, onError: (_) {});
    return run;
  }

  Future<String?> _whisperLrc(Track t) {
    return _exclusive<String?>(() async {
      try {
        WakelockPlus.enable();
        final model = whisperModel == 'large'
            ? WhisperModel.largeV3Turbo
            : (whisperModel == 'small' ? WhisperModel.small : WhisperModel.base);
        final sizeNote = whisperModel == 'large'
            ? '~1,5 ГБ'
            : (whisperModel == 'small' ? '~466 МБ' : '~142 МБ');
        final mp = await _wc.getPath(model);
        if (!await File(mp).exists()) {
          if (current == t) {
            lyricsStatus = 'Скачиваю модель распознавания ($sizeNote, один раз)…\nЛучше на Wi-Fi.';
            notifyListeners();
          }
          await _wc.downloadModel(model);
        }
        if (current == t) {
          lyricsStatus = 'Распознаю текст на телефоне…\nОдна песня — примерно 1–3 минуты.';
          notifyListeners();
        }
        final res = await _wc.transcribe(
          model: model,
          audioPath: t.path,
          lang: whisperLang,
          withTimestamps: true,
          threads: 4,
          vadMode: WhisperVadMode.disabled,
        );
        final segs = res?.transcription.segments;
        if (segs == null || segs.isEmpty) return null;

        final b = StringBuffer();
        String lastNorm = '';
        int rep = 0;
        for (final sg in segs) {
          var text = sg.text.trim();
          if (text.isEmpty) continue;
          // служебные пометки Whisper вроде [Music] → значок ноты
          if (RegExp(r'^[\[\(\*♪].*[\]\)\*♪]$').hasMatch(text)) text = '';
          // Whisper иногда зацикливается и повторяет одну фразу — режем после 3 раз
          final norm = text.toLowerCase();
          if (norm == lastNorm) {
            rep++;
            if (rep >= 3) continue;
          } else {
            rep = 0;
            lastNorm = norm;
          }
          final from = sg.fromTs.inMilliseconds;
          final to = math.max(sg.toTs.inMilliseconds, from + 500);
          for (final part in _splitLong(text, from, to)) {
            final ms = part.$1;
            final m = ms ~/ 60000;
            final s = ((ms % 60000) / 1000).toStringAsFixed(2).padLeft(5, '0');
            b.writeln('[${_p2(m)}:$s]${part.$2}');
          }
        }
        final out = b.toString();
        return out.trim().isEmpty ? null : out;
      } catch (e) {
        var msg = e.toString();
        if (msg.length > 160) msg = '${msg.substring(0, 160)}…';
        batchError = msg;
        return null;
      } finally {
        if (!batchRunning) WakelockPlus.disable();
      }
    });
  }

  // длинную строку делим на куски ≤ ~42 символов, время — пропорционально
  List<(int, String)> _splitLong(String text, int from, int to) {
    if (text.length <= 48) return [(from, text)];
    final words = text.split(RegExp(r'\s+'));
    final chunks = <String>[];
    var cur = '';
    for (final w in words) {
      if (cur.isNotEmpty && cur.length + w.length + 1 > 42) {
        chunks.add(cur);
        cur = w;
      } else {
        cur = cur.isEmpty ? w : '$cur $w';
      }
    }
    if (cur.isNotEmpty) chunks.add(cur);
    final res = <(int, String)>[];
    var acc = 0;
    for (final ch in chunks) {
      res.add((from + ((to - from) * acc / text.length).round(), ch));
      acc += ch.length + 1;
    }
    return res;
  }

  bool _hasLyrics(Track t) {
    if (prefs?.containsKey('edit:${t.path}') ?? false) return true;
    if (prefs?.containsKey('lrc:${t.artist}|${t.title}') ?? false) return true;
    final dot = t.path.lastIndexOf('.');
    return dot > 0 && File('${t.path.substring(0, dot)}.lrc').existsSync();
  }

  /// Распознать тексты для всех песен, у которых их ещё нет
  Future<void> transcribeAll() async {
    if (batchRunning || tracks.isEmpty) return;
    batchRunning = true;
    batchDone = 0;
    batchTotal = tracks.length;
    batchError = '';
    notifyListeners();
    for (final t in List<Track>.of(tracks)) {
      if (!batchRunning) break;
      await t.loadMeta();
      _applyCustom(t);
      if (!_hasLyrics(t)) {
        final lrc = await _whisperLrc(t);
        if (lrc != null) prefs?.setString('lrc:${t.artist}|${t.title}', lrc);
      }
      batchDone++;
      notifyListeners();
    }
    batchRunning = false;
    WakelockPlus.disable();
    notifyListeners();
  }

  void cancelBatch() {
    batchRunning = false;
    notifyListeners();
  }

  void setLang(String l) {
    whisperLang = l;
    prefs?.setString('wlang', l);
    notifyListeners();
  }

  void setModel(String m) {
    whisperModel = m;
    prefs?.setString('wmodel', m);
    notifyListeners();
  }

  // ── свои названия, сдвиг времени, правка строк ──

  void _applyCustom(Track t) {
    final s = prefs?.getString('name:${t.path}');
    if (s == null) return;
    final i = s.indexOf('|');
    if (i < 0) return;
    final a = s.substring(0, i).trim();
    final ti = s.substring(i + 1).trim();
    t.artist = a.isEmpty ? 'Неизвестный исполнитель' : a;
    if (ti.isNotEmpty) t.title = ti;
  }

  Future<void> renameTrack(String artist, String title) async {
    final t = current;
    if (t == null) return;
    prefs?.setString('name:${t.path}', '$artist|$title');
    _applyCustom(t);
    notifyListeners();
    await reloadLyrics();
  }

  void setOffset(Duration d) {
    offset = d;
    final t = current;
    if (t != null) prefs?.setInt('off:${t.path}', d.inMilliseconds);
    line.value = -2; // принудительно пересчитать строку
    _updateLine(pos.value);
    notifyListeners();
  }

  Future<void> seekToLine(int i) async {
    if (i < 0 || i >= lyrics.length) return;
    final target = lyrics[i].time - offset;
    await player.seek(target > Duration.zero ? target : Duration.zero);
  }

  String _lrcTime(Duration d) {
    final ms = d.inMilliseconds;
    final m = ms ~/ 60000;
    final s = ((ms % 60000) / 1000).toStringAsFixed(2).padLeft(5, '0');
    return '[${_p2(m)}:$s]';
  }

  Future<void> editLine(int i, String text) async {
    final t = current;
    if (t == null || i < 0 || i >= lyrics.length) return;
    final b = StringBuffer();
    for (int k = 0; k < lyrics.length; k++) {
      final ln = lyrics[k];
      b.writeln('${_lrcTime(ln.time)}${k == i ? text.trim() : ln.text}');
    }
    final lrc = b.toString();
    prefs?.setString('edit:${t.path}', lrc);
    lyrics = parseLrc(lrc);
    line.value = -2;
    _updateLine(pos.value);
    notifyListeners();
  }

  Future<String?> _fetchLrclib(Track t) async {
    final dur = (player.duration ?? t.duration)?.inSeconds;
    const headers = {'User-Agent': 'PopstarPlayer/1.0'};
    try {
      final q = <String, String>{'track_name': t.title};
      if (t.artistKnown) q['artist_name'] = t.artist;
      if (t.album.isNotEmpty) q['album_name'] = t.album;
      if (dur != null) q['duration'] = '$dur';
      final r = await http
          .get(Uri.https('lrclib.net', '/api/get', q), headers: headers)
          .timeout(const Duration(seconds: 8));
      if (r.statusCode == 200) {
        final j = jsonDecode(utf8.decode(r.bodyBytes));
        final s = _pickLyrics(j, dur);
        if (s != null) return s;
      }
      final r2 = await http
          .get(
              Uri.https('lrclib.net', '/api/search',
                  {'q': t.artistKnown ? '${t.artist} ${t.title}' : t.title}),
              headers: headers)
          .timeout(const Duration(seconds: 8));
      if (r2.statusCode == 200) {
        final list = jsonDecode(utf8.decode(r2.bodyBytes));
        if (list is List) {
          bool durOk(dynamic it) {
            if (dur == null || it is! Map) return true;
            final d = it['duration'];
            return d is num && (d - dur).abs() <= 4;
          }
          for (final it in list) {
            if (!durOk(it)) continue;
            final s = it is Map ? it['syncedLyrics'] : null;
            if (s is String && s.trim().isNotEmpty) return s;
          }
          for (final it in list) {
            if (!durOk(it)) continue;
            final s = _pickLyrics(it, dur);
            if (s != null) return s;
          }
        }
      }
    } catch (_) {}
    return null;
  }

  String? _pickLyrics(dynamic j, int? dur) {
    if (j is! Map) return null;
    final synced = j['syncedLyrics'];
    if (synced is String && synced.trim().isNotEmpty) return synced;
    final plain = j['plainLyrics'];
    if (plain is String && plain.trim().isNotEmpty) {
      return pseudoLrc(plain, dur ?? 180);
    }
    return null;
  }

  void _updateLine(Duration raw) {
    final p = raw + offset;
    if (lyrics.isEmpty) {
      if (line.value != -1) line.value = -1;
      return;
    }
    int lo = 0, hi = lyrics.length - 1, ans = -1;
    while (lo <= hi) {
      final mid = (lo + hi) >> 1;
      if (lyrics[mid].time <= p) {
        ans = mid;
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
    if (ans != line.value) {
      line.value = ans;
      love.value = ans < 0 ? 0.04 : lyrics[ans].love;
    }
  }

  @override
  void dispose() {
    _s1?.cancel();
    _s2?.cancel();
    _s3?.cancel();
    player.dispose();
    super.dispose();
  }
}

// ───────────────────────── Приложение ─────────────────────────

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  WhisperFFmpegConverter.register(); // mp3/m4a/flac → wav для Whisper
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: kBg,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(const PopstarApp());
}

class PopstarApp extends StatelessWidget {
  const PopstarApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Popstar',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        scaffoldBackgroundColor: kBg,
        colorScheme: const ColorScheme.dark(primary: kRed),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final c = PlayerController();
  bool ready = false;
  bool busy = false;
  String? error;

  @override
  void initState() {
    super.initState();
    _boot();
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  Future<void> _boot() async {
    await c.init();
    if (c.folder != null && await c.hasPermission()) {
      if (c.folder == '/storage/emulated/0') {
        await c.scanAll();
      } else {
        await c.scanFolder(c.folder!);
      }
      if (c.tracks.isNotEmpty) c.play(0);
    }
    if (mounted) setState(() => ready = true);
  }

  Future<void> _afterScan() async {
    if (c.tracks.isNotEmpty) {
      error = null;
      c.play(0);
    } else {
      error = 'Музыка не найдена. Выбери папку вручную.';
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _grant() async {
    setState(() {
      busy = true;
      error = null;
    });
    final ok = await c.ensurePermission();
    if (!ok) {
      if (mounted) {
        setState(() {
          busy = false;
          error = 'Доступ не выдан. Разреши его в настройках приложения.';
        });
      }
      return;
    }
    await c.scanAll();
    await _afterScan();
  }

  Future<void> _pickFolder() async {
    if (!await c.ensurePermission()) {
      if (mounted) setState(() => error = 'Нужен доступ к музыке.');
      return;
    }
    final dir = await FilePicker.platform.getDirectoryPath();
    if (dir == null) return;
    if (mounted) setState(() => busy = true);
    await c.scanFolder(dir);
    await _afterScan();
  }

  Future<void> _pickFiles() async {
    final res = await FilePicker.platform
        .pickFiles(type: FileType.audio, allowMultiple: true);
    if (res == null) return;
    final paths = res.paths.whereType<String>().toList();
    if (paths.isEmpty) return;
    c.setFiles(paths);
    await _afterScan();
  }

  Future<void> _renameDialog() async {
    final t = c.current;
    if (t == null) return;
    final a = TextEditingController(text: t.artistKnown ? t.artist : '');
    final n = TextEditingController(text: t.nameUseless ? '' : t.title);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1D1D21),
        title: const Text('Какая это песня?'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
              controller: a,
              decoration: const InputDecoration(labelText: 'Исполнитель')),
          TextField(
              controller: n,
              decoration: const InputDecoration(labelText: 'Название')),
        ]),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Отмена')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Найти текст')),
        ],
      ),
    );
    if (ok == true && n.text.trim().isNotEmpty) {
      await c.renameTrack(a.text.trim(), n.text.trim());
    }
  }

  void _openLyricsMenu() {
    final t = c.current;
    if (t == null) return;
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF17171A),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => ListenableBuilder(
        listenable: c,
        builder: (ctx, _) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 16, 12, 12),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Text('Текст песни',
                      style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.w700)),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 2, 8, 8),
                  child: Text('${t.artist} — ${t.title}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: wa(.6))),
                ),
                ListTile(
                  leading: const Icon(Icons.search),
                  title: const Text('Найти по названию заново'),
                  subtitle: const Text('Онлайн-база, потом распознавание'),
                  onTap: () {
                    Navigator.pop(ctx);
                    c.reloadLyrics();
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.hearing),
                  title: const Text('Распознать по звуку'),
                  subtitle: const Text('Телефон слушает песню, без интернета'),
                  onTap: () {
                    Navigator.pop(ctx);
                    c.reloadLyrics(onlyWhisper: true);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.edit),
                  title: const Text('Указать исполнителя и название'),
                  subtitle: const Text('Если файл назван цифрами'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _renameDialog();
                  },
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
                  child: Text('Сдвиг времени текста',
                      style: TextStyle(color: wa(.6), fontSize: 13)),
                ),
                Row(children: [
                  IconButton(
                    onPressed: () =>
                        c.setOffset(c.offset - const Duration(milliseconds: 500)),
                    icon: const Icon(Icons.remove_circle_outline),
                  ),
                  Text(
                      '${c.offset.inMilliseconds >= 0 ? '+' : ''}${(c.offset.inMilliseconds / 1000).toStringAsFixed(1)} с',
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.w600)),
                  IconButton(
                    onPressed: () =>
                        c.setOffset(c.offset + const Duration(milliseconds: 500)),
                    icon: const Icon(Icons.add_circle_outline),
                  ),
                  Expanded(
                    child: Text('«+» — текст раньше, «−» — позже',
                        style: TextStyle(color: wa(.5), fontSize: 12)),
                  ),
                ]),
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 4, 8, 0),
                  child: Text(
                      'Совет: удерживай строку текста, чтобы исправить слово.',
                      style: TextStyle(color: wa(.5), fontSize: 12)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _scanAllFromSheet() async {
    if (!await c.ensurePermission()) return;
    await c.scanAll();
    if (c.index < 0 && c.tracks.isNotEmpty) c.play(0);
  }

  void _openLibrary() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF17171A),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.75,
        minChildSize: 0.4,
        maxChildSize: 0.95,
        builder: (ctx, sc) => ListenableBuilder(
          listenable: c,
          builder: (ctx, _) => Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 8, 4),
              child: Row(children: [
                Expanded(
                  child: Text('Треков: ${c.tracks.length}',
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.w700)),
                ),
                TextButton(onPressed: _scanAllFromSheet, child: const Text('Вся память')),
                TextButton(onPressed: _pickFolder, child: const Text('Папка')),
                TextButton(onPressed: _pickFiles, child: const Text('Файлы')),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Язык песен для распознавания',
                    style: TextStyle(fontSize: 12, color: wa(.6))),
                const SizedBox(height: 6),
                Wrap(spacing: 8, children: [
                  for (final e in const {
                    'auto': 'Авто',
                    'en': 'English',
                    'ru': 'Русский',
                  }.entries)
                    ChoiceChip(
                      label: Text(e.value),
                      selected: c.whisperLang == e.key,
                      onSelected: (_) => c.setLang(e.key),
                    ),
                ]),
                const SizedBox(height: 10),
                Text('Точность распознавания',
                    style: TextStyle(fontSize: 12, color: wa(.6))),
                const SizedBox(height: 6),
                Wrap(spacing: 8, children: [
                  ChoiceChip(
                    label: const Text('Быстрая (142 МБ)'),
                    selected: c.whisperModel == 'base',
                    onSelected: (_) => c.setModel('base'),
                  ),
                  ChoiceChip(
                    label: const Text('Точная (466 МБ, медленнее)'),
                    selected: c.whisperModel == 'small',
                    onSelected: (_) => c.setModel('small'),
                  ),
                  ChoiceChip(
                    label: const Text('Максимум (1,5 ГБ, очень медленно)'),
                    selected: c.whisperModel == 'large',
                    onSelected: (_) => c.setModel('large'),
                  ),
                ]),
                const SizedBox(height: 8),
                if (c.batchRunning) ...[
                  LinearProgressIndicator(
                      value: c.batchTotal == 0 ? null : c.batchDone / c.batchTotal,
                      color: kRed),
                  Row(children: [
                    Expanded(
                        child: Text('Распознаю: ${c.batchDone}/${c.batchTotal}',
                            style: TextStyle(color: wa(.7)))),
                    TextButton(onPressed: c.cancelBatch, child: const Text('Стоп')),
                  ]),
                ] else
                  OutlinedButton.icon(
                    onPressed: c.transcribeAll,
                    icon: const Icon(Icons.auto_awesome),
                    label: const Text('Распознать тексты всех песен'),
                  ),
              ]),
            ),
            Expanded(
              child: ListView.builder(
                controller: sc,
                itemCount: c.tracks.length,
                itemBuilder: (ctx, i) {
                  final t = c.tracks[i];
                  final sel = i == c.index;
                  return ListTile(
                    selected: sel,
                    selectedColor: kRed,
                    leading: Icon(sel ? Icons.graphic_eq : Icons.music_note),
                    title:
                        Text(t.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text(t.artist,
                        maxLines: 1, overflow: TextOverflow.ellipsis),
                    onTap: () {
                      c.play(i);
                      Navigator.pop(ctx);
                    },
                  );
                },
              ),
            ),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [
        Positioned.fill(child: Backdrop(c: c)),
        const Positioned.fill(child: Particles()),
        SafeArea(
          child: !ready
              ? const Center(child: CircularProgressIndicator(color: kRed))
              : ListenableBuilder(
                  listenable: c,
                  builder: (ctx, _) {
                    if (c.tracks.isEmpty || c.current == null) {
                      return Welcome(
                        busy: busy,
                        error: error,
                        onGrant: _grant,
                        onFolder: _pickFolder,
                        onFiles: _pickFiles,
                      );
                    }
                    return PlayerScreen(
                        c: c,
                        onLibrary: _openLibrary,
                        onLyricsMenu: _openLyricsMenu);
                  },
                ),
        ),
      ]),
    );
  }
}

// ───────────────────────── Экран приветствия ─────────────────────────

class Welcome extends StatelessWidget {
  final bool busy;
  final String? error;
  final VoidCallback onGrant, onFolder, onFiles;
  const Welcome({
    super.key,
    required this.busy,
    required this.error,
    required this.onGrant,
    required this.onFolder,
    required this.onFiles,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(28),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 440),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: kRed,
                boxShadow: [BoxShadow(color: ca(kRed, .5), blurRadius: 40)],
              ),
              child: const Icon(Icons.music_note_rounded, size: 52),
            ),
            const SizedBox(height: 28),
            const Text('Popstar',
                style: TextStyle(fontSize: 38, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            Text(
              'Дай доступ к папке с музыкой — и каждый трек получит живой текст, '
              'шкалу «Любви» и растущую «Славу».',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, height: 1.4, color: wa(.65)),
            ),
            const SizedBox(height: 32),
            if (busy)
              const CircularProgressIndicator(color: kRed)
            else ...[
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(
                      backgroundColor: kRed,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16)),
                  onPressed: onGrant,
                  icon: const Icon(Icons.folder_open),
                  label: const Text('Дать доступ к музыке'),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16)),
                  onPressed: onFolder,
                  child: const Text('Выбрать папку'),
                ),
              ),
              TextButton(
                  onPressed: onFiles, child: const Text('Выбрать отдельные файлы')),
            ],
            if (error != null) ...[
              const SizedBox(height: 16),
              Text(error!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: kRed)),
            ],
          ]),
        ),
      ),
    );
  }
}

// ───────────────────────── Раскладки ─────────────────────────

class PlayerScreen extends StatelessWidget {
  final PlayerController c;
  final VoidCallback onLibrary;
  final VoidCallback onLyricsMenu;
  const PlayerScreen(
      {super.key,
      required this.c,
      required this.onLibrary,
      required this.onLyricsMenu});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (ctx, cons) {
      final w = cons.maxWidth, h = cons.maxHeight;

      // Планшет / широкий экран — как в видео
      if (w >= 900 && h >= 800) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(40, 24, 40, 28),
          child: Row(children: [
            Expanded(
              flex: 5,
              child: Column(children: [
                Expanded(flex: 31, child: CoverCard(c: c)),
                const SizedBox(height: 18),
                Expanded(flex: 20, child: PlayerCard(c: c, onLibrary: onLibrary, onLyricsMenu: onLyricsMenu)),
                const SizedBox(height: 18),
                Expanded(
                  flex: 33,
                  child: Row(children: [
                    Expanded(child: FameCard(c: c)),
                    const SizedBox(width: 18),
                    Expanded(child: LoveCard(c: c)),
                  ]),
                ),
              ]),
            ),
            const SizedBox(width: 56),
            Expanded(flex: 6, child: LyricsView(c: c, big: true)),
          ]),
        );
      }

      // Телефон в горизонтали
      if (w > h) {
        return Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            SizedBox(
              width: w * 0.42,
              child: Column(children: [
                Expanded(child: CoverCard(c: c, compact: true)),
                const SizedBox(height: 10),
                PlayerCard(c: c, compact: true, onLibrary: onLibrary, onLyricsMenu: onLyricsMenu),
              ]),
            ),
            const SizedBox(width: 20),
            Expanded(child: LyricsView(c: c, big: false)),
          ]),
        );
      }

      // Телефон в вертикали
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
        child: Column(children: [
          SizedBox(height: 130, child: CoverCard(c: c, compact: true)),
          const SizedBox(height: 12),
          PlayerCard(c: c, compact: true, onLibrary: onLibrary, onLyricsMenu: onLyricsMenu),
          const SizedBox(height: 12),
          SizedBox(
            height: 140,
            child: Row(children: [
              Expanded(child: FameCard(c: c, compact: true)),
              const SizedBox(width: 12),
              Expanded(child: LoveCard(c: c)),
            ]),
          ),
          const SizedBox(height: 14),
          Expanded(child: LyricsView(c: c, big: false)),
        ]),
      );
    });
  }
}

// ───────────────────────── Фон и частицы ─────────────────────────

class Backdrop extends StatelessWidget {
  final PlayerController c;
  const Backdrop({super.key, required this.c});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<double>(
      valueListenable: c.love,
      builder: (ctx, love, _) => TweenAnimationBuilder<double>(
        tween: Tween<double>(begin: 0, end: love),
        duration: const Duration(milliseconds: 900),
        builder: (ctx, v, _) => DecoratedBox(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0.9, 0.7),
              radius: 1.35,
              colors: [
                Color.lerp(const Color(0xFF45101A), const Color(0xFF9A1226), v)!,
                kBg,
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class Particles extends StatefulWidget {
  const Particles({super.key});
  @override
  State<Particles> createState() => _ParticlesState();
}

class _ParticlesState extends State<Particles>
    with SingleTickerProviderStateMixin {
  late final AnimationController _t =
      AnimationController(vsync: this, duration: const Duration(seconds: 60))
        ..repeat();
  final _rnd = math.Random(7);
  late final List<List<double>> _p = List.generate(
    50,
    (_) => [
      _rnd.nextDouble(),
      _rnd.nextDouble(),
      0.3 + _rnd.nextDouble() * 1.2,
      0.8 + _rnd.nextDouble() * 1.8,
      0.2 + _rnd.nextDouble() * 0.4,
    ],
  );

  @override
  void dispose() {
    _t.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: CustomPaint(
        size: Size.infinite,
        painter: _ParticlePainter(_t, _p),
      ),
    );
  }
}

class _ParticlePainter extends CustomPainter {
  final Animation<double> t;
  final List<List<double>> p;
  _ParticlePainter(this.t, this.p) : super(repaint: t);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();
    for (final q in p) {
      final y = (q[1] - t.value * q[2]) % 1.0;
      final x = q[0] + math.sin(t.value * 2 * math.pi * q[2] + q[1] * 6) * 0.01;
      paint.color = wa(q[4]);
      canvas.drawCircle(Offset(x * size.width, y * size.height), q[3], paint);
    }
  }

  @override
  bool shouldRepaint(covariant _ParticlePainter old) => false;
}

// ───────────────────────── Карточки ─────────────────────────

class Glass extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  const Glass({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 28,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        color: wa(.07),
        border: Border.all(color: wa(.07)),
      ),
      child: child,
    );
  }
}

class CoverCard extends StatefulWidget {
  final PlayerController c;
  final bool compact;
  const CoverCard({super.key, required this.c, this.compact = false});
  @override
  State<CoverCard> createState() => _CoverCardState();
}

class _CoverCardState extends State<CoverCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _kb =
      AnimationController(vsync: this, duration: const Duration(seconds: 16))
        ..repeat(reverse: true);

  static const _gray = ColorFilter.matrix(<double>[
    0.2126, 0.7152, 0.0722, 0, 0,
    0.2126, 0.7152, 0.0722, 0, 0,
    0.2126, 0.7152, 0.0722, 0, 0,
    0, 0, 0, 1, 0,
  ]);

  @override
  void dispose() {
    _kb.dispose();
    super.dispose();
  }

  Widget _art(Uint8List? cover) {
    if (cover != null) {
      return ColorFiltered(
        colorFilter: _gray,
        child: Image.memory(cover, fit: BoxFit.cover, gaplessPlayback: true),
      );
    }
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF2A2A30), Color(0xFF5B1621)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Center(
        child: Icon(Icons.music_note_rounded, size: 64, color: wa(.25)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.c;
    final fs = widget.compact ? 11.0 : 15.0;
    return ListenableBuilder(
      listenable: c,
      builder: (ctx, _) {
        final t = c.current;
        return ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: Stack(fit: StackFit.expand, children: [
            AnimatedBuilder(
              animation: _kb,
              builder: (ctx, _) {
                final v = Curves.easeInOut.transform(_kb.value);
                return Transform.scale(
                  scale: 1.08 + 0.14 * v,
                  alignment: Alignment(-0.4 + 0.8 * v, 0.2),
                  child: _art(t?.cover),
                );
              },
            ),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, ca(Colors.black, .7)],
                  stops: const [0.45, 1],
                ),
              ),
            ),
            Positioned(
              left: 14,
              top: 14,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: ca(Colors.black, .4),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(c.playing ? Icons.graphic_eq : Icons.pause, size: 16),
                  const SizedBox(width: 6),
                  Text(c.playing ? 'Сейчас играет' : 'Пауза',
                      style: TextStyle(fontSize: fs, fontWeight: FontWeight.w600)),
                ]),
              ),
            ),
            Positioned(
              left: 18,
              right: 110,
              bottom: 12,
              child: Text(
                '${t?.artist ?? ''} · ${t?.title ?? ''}'.toUpperCase(),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: fs, fontWeight: FontWeight.w600, letterSpacing: .3),
              ),
            ),
            Positioned(
              right: 18,
              bottom: 12,
              child: ValueListenableBuilder<Duration>(
                valueListenable: c.pos,
                builder: (ctx, p, _) => Text(fmtHms(p),
                    style: TextStyle(
                        fontSize: fs,
                        fontWeight: FontWeight.w600,
                        fontFeatures: const [FontFeature.tabularFigures()])),
              ),
            ),
          ]),
        );
      },
    );
  }
}

class _RoundBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool active;
  const _RoundBtn({required this.icon, required this.onTap, this.active = false});

  @override
  Widget build(BuildContext context) {
    return InkResponse(
      onTap: onTap,
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(shape: BoxShape.circle, color: wa(.1)),
        child: Icon(icon, size: 20, color: active ? kRed : Colors.white),
      ),
    );
  }
}

class PlayerCard extends StatefulWidget {
  final PlayerController c;
  final bool compact;
  final VoidCallback onLibrary;
  final VoidCallback onLyricsMenu;
  const PlayerCard(
      {super.key,
      required this.c,
      required this.onLibrary,
      required this.onLyricsMenu,
      this.compact = false});
  @override
  State<PlayerCard> createState() => _PlayerCardState();
}

class _PlayerCardState extends State<PlayerCard> {
  double vol = 1.0;

  @override
  Widget build(BuildContext context) {
    final c = widget.c;
    final compact = widget.compact;
    return ListenableBuilder(
      listenable: c,
      builder: (ctx, _) {
        final t = c.current;
        final fav = t != null && c.favs.contains(t.path);

        final transport = Row(mainAxisSize: MainAxisSize.min, children: [
          IconButton(
              iconSize: compact ? 32 : 40,
              onPressed: c.prev,
              icon: const Icon(Icons.fast_rewind_rounded)),
          IconButton(
              iconSize: compact ? 44 : 54,
              onPressed: c.togglePlay,
              icon: Icon(c.playing
                  ? Icons.pause_rounded
                  : Icons.play_arrow_rounded)),
          IconButton(
              iconSize: compact ? 32 : 40,
              onPressed: c.next,
              icon: const Icon(Icons.fast_forward_rounded)),
        ]);

        final lyricsBtn = Tooltip(
          message: 'Текст песни',
          child: InkResponse(
            onTap: widget.onLyricsMenu,
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.chat_bubble, size: 20, color: Colors.black),
            ),
          ),
        );

        final Widget controls;
        if (compact) {
          controls = Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            transport,
            const SizedBox(width: 14),
            lyricsBtn,
          ]);
        } else {
          controls = Row(children: [
            SizedBox(
              width: 150,
              child: Row(children: [
                Icon(vol == 0 ? Icons.volume_off : Icons.volume_down,
                    size: 20, color: wa(.6)),
                Expanded(
                  child: SliderTheme(
                    data: _sliderTheme(context),
                    child: Slider(
                      value: vol,
                      onChanged: (v) {
                        setState(() => vol = v);
                        c.player.setVolume(v);
                      },
                    ),
                  ),
                ),
              ]),
            ),
            const Spacer(),
            transport,
            const Spacer(),
            SizedBox(
              width: 150,
              child: Align(alignment: Alignment.centerRight, child: lyricsBtn),
            ),
          ]);
        }

        return Glass(
          padding: EdgeInsets.all(compact ? 14 : 22),
          child: Column(
            mainAxisSize: compact ? MainAxisSize.min : MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(t?.title ?? '',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontSize: compact ? 22 : 34,
                              fontWeight: FontWeight.w700)),
                      Text(t?.artist ?? '',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontSize: compact ? 15 : 22, color: wa(.55))),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                _RoundBtn(
                    icon: fav ? Icons.star : Icons.star_border,
                    active: fav,
                    onTap: c.toggleFav),
                const SizedBox(width: 8),
                _RoundBtn(icon: Icons.more_horiz, onTap: widget.onLibrary),
              ]),
              SizedBox(height: compact ? 4 : 0),
              SeekBar(c: c),
              controls,
            ],
          ),
        );
      },
    );
  }
}

SliderThemeData _sliderTheme(BuildContext context) =>
    SliderTheme.of(context).copyWith(
      trackHeight: 3,
      activeTrackColor: Colors.white,
      inactiveTrackColor: wa(.2),
      thumbColor: Colors.white,
      thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
      overlayShape: const RoundSliderOverlayShape(overlayRadius: 14),
      trackShape: const RoundedRectSliderTrackShape(),
    );

class SeekBar extends StatefulWidget {
  final PlayerController c;
  const SeekBar({super.key, required this.c});
  @override
  State<SeekBar> createState() => _SeekBarState();
}

class _SeekBarState extends State<SeekBar> {
  double? drag;

  @override
  Widget build(BuildContext context) {
    final c = widget.c;
    return ValueListenableBuilder<Duration>(
      valueListenable: c.pos,
      builder: (ctx, pos, _) {
        final dur = c.duration;
        final total = math.max(dur.inMilliseconds, 1);
        final v = drag ?? (pos.inMilliseconds / total).clamp(0.0, 1.0).toDouble();
        final shown = Duration(milliseconds: (v * total).round());
        final rem = dur > shown ? dur - shown : Duration.zero;
        final style = TextStyle(
            fontSize: 13,
            color: wa(.7),
            fontFeatures: const [FontFeature.tabularFigures()]);
        return Row(children: [
          Text(fmt(shown), style: style),
          Expanded(
            child: SliderTheme(
              data: _sliderTheme(context),
              child: Slider(
                value: v,
                onChanged: (x) => setState(() => drag = x),
                onChangeEnd: (x) {
                  c.player.seek(Duration(milliseconds: (x * total).round()));
                  setState(() => drag = null);
                },
              ),
            ),
          ),
          Text('-${fmt(rem)}', style: style),
        ]);
      },
    );
  }
}

// ── «Слава»: растущий счётчик слушателей (декоративный) ──

class FameCard extends StatelessWidget {
  final PlayerController c;
  final bool compact;
  const FameCard({super.key, required this.c, this.compact = false});

  @override
  Widget build(BuildContext context) {
    return Glass(
      padding: EdgeInsets.all(compact ? 12 : 20),
      child: ListenableBuilder(
        listenable: c,
        builder: (ctx, _) => ValueListenableBuilder<Duration>(
          valueListenable: c.pos,
          builder: (ctx, pos, _) {
            final t = c.current;
            final total = math.max(c.duration.inMilliseconds, 1);
            final p = (pos.inMilliseconds / total).clamp(0.0, 1.0).toDouble();
            final seed = t == null ? 1 : stableHash('${t.artist}${t.title}');
            final target = 300000 + (seed % 9000000);
            final listeners =
                (target * (0.05 + 0.95 * math.pow(p, 1.6))).round();
            final label = p < .2
                ? 'В рекомендациях'
                : p < .5
                    ? 'В тренде'
                    : p < .8
                        ? 'В топе'
                        : 'Топ-1';
            const bars = 22;
            final lit = 6 + (p * 16).round();
            final redN = p < .15 ? 0 : (2 + p * 4).round();
            final sub = TextStyle(fontSize: compact ? 11 : 15, color: wa(.7));

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Icon(Icons.star, color: kRed, size: compact ? 16 : 22),
                  const SizedBox(width: 6),
                  Text('Слава',
                      style: TextStyle(
                          fontSize: compact ? 14 : 20,
                          fontWeight: FontWeight.w600)),
                  const Spacer(),
                  Text('Сейчас', style: sub),
                ]),
                const Spacer(),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerLeft,
                  child: Text(groupNum(listeners),
                      style: TextStyle(
                          fontSize: compact ? 24 : 46,
                          fontWeight: FontWeight.w800,
                          fontFeatures: const [FontFeature.tabularFigures()])),
                ),
                Text('слушателей', style: sub),
                const Spacer(),
                SizedBox(
                  height: compact ? 22 : 56,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: List.generate(bars, (i) {
                      final h = 0.14 + 0.86 * math.pow(i / (bars - 1), 1.4);
                      Color col;
                      if (i >= lit) {
                        col = wa(.12);
                      } else if (i >= lit - redN) {
                        col = kRed;
                      } else {
                        col = wa(.5);
                      }
                      return Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 1.2),
                          child: FractionallySizedBox(
                            heightFactor: h.toDouble(),
                            alignment: Alignment.bottomCenter,
                            child: DecoratedBox(
                              decoration: BoxDecoration(
                                color: col,
                                borderRadius: BorderRadius.circular(3),
                              ),
                            ),
                          ),
                        ),
                      );
                    }),
                  ),
                ),
                const SizedBox(height: 6),
                Text(label, style: sub),
              ],
            );
          },
        ),
      ),
    );
  }
}

// ── «Любовь»: кольцо, которое реагирует на слова в тексте ──

class _RingPainter extends CustomPainter {
  final double v;
  _RingPainter(this.v);

  @override
  void paint(Canvas canvas, Size size) {
    final ctr = size.center(Offset.zero);
    final r = size.width / 2 - 6;
    canvas.drawCircle(
        ctr,
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 8
          ..color = wa(.12));
    final sweep = 2 * math.pi * v.clamp(0.0, 1.0).toDouble();
    canvas.drawArc(
        Rect.fromCircle(center: ctr, radius: r),
        -math.pi / 2,
        sweep,
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 8
          ..strokeCap = StrokeCap.round
          ..color = kRed);
    final ang = -math.pi / 2 + sweep;
    canvas.drawCircle(
        ctr + Offset(math.cos(ang) * r, math.sin(ang) * r), 5, Paint()..color = kRed);
  }

  @override
  bool shouldRepaint(covariant _RingPainter old) => old.v != v;
}

class LoveCard extends StatelessWidget {
  final PlayerController c;
  const LoveCard({super.key, required this.c});

  @override
  Widget build(BuildContext context) {
    return Glass(
      padding: const EdgeInsets.all(14),
      child: ValueListenableBuilder<int>(
        valueListenable: c.line,
        builder: (ctx, idx, _) {
          final has = idx >= 0 && idx < c.lyrics.length;
          final lv = has ? c.lyrics[idx].love : 0.04;
          final label = has ? c.lyrics[idx].label : '—';
          final hot = lv >= .5;
          return Column(children: [
            Row(children: [
              const Icon(Icons.favorite, color: kRed, size: 20),
              const SizedBox(width: 6),
              const Text('Любовь',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              const Spacer(),
              Text('Сейчас', style: TextStyle(fontSize: 12, color: wa(.7))),
            ]),
            Expanded(
              child: LayoutBuilder(builder: (ctx, cons) {
                final s = math.min(cons.maxWidth, cons.maxHeight) * 0.92;
                return Center(
                  child: TweenAnimationBuilder<double>(
                    tween: Tween<double>(begin: 0, end: lv),
                    duration: const Duration(milliseconds: 700),
                    curve: Curves.easeOut,
                    builder: (ctx, v, _) => SizedBox(
                      width: s,
                      height: s,
                      child: CustomPaint(
                        painter: _RingPainter(v),
                        child: Center(
                          child: Text('${(v * 100).round()}%',
                              style: TextStyle(
                                  fontSize: math.max(12, s * 0.22),
                                  fontWeight: FontWeight.w700)),
                        ),
                      ),
                    ),
                  ),
                );
              }),
            ),
            AnimatedContainer(
              duration: const Duration(milliseconds: 400),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
              decoration: BoxDecoration(
                color: hot ? kRed : wa(.1),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
            ),
          ]);
        },
      ),
    );
  }
}

// ───────────────────────── Текст песни ─────────────────────────

class LyricsView extends StatelessWidget {
  final PlayerController c;
  final bool big;
  const LyricsView({super.key, required this.c, required this.big});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Icon(Icons.chat_bubble, size: big ? 20 : 16, color: wa(.6)),
        const SizedBox(width: 8),
        Text('Текст песни',
            style: TextStyle(
                color: wa(.6),
                fontSize: big ? 20 : 15,
                fontWeight: FontWeight.w600)),
        const SizedBox(width: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          decoration:
              BoxDecoration(color: wa(.12), borderRadius: BorderRadius.circular(6)),
          child: Text('LIVE',
              style: TextStyle(
                  fontSize: 10, color: wa(.7), fontWeight: FontWeight.w700)),
        ),
      ]),
      Expanded(
        child: ListenableBuilder(
          listenable: Listenable.merge([c, c.line]),
          builder: (ctx, _) {
            if (c.lyrics.isEmpty) {
              return Center(
                child: c.lyricsLoading
                    ? Column(mainAxisSize: MainAxisSize.min, children: [
                        const CircularProgressIndicator(color: kRed),
                        if (c.lyricsStatus.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.all(16),
                            child: Text(c.lyricsStatus,
                                textAlign: TextAlign.center,
                                style: TextStyle(color: wa(.55), fontSize: 14)),
                          ),
                      ])
                    : Padding(
                        padding: const EdgeInsets.all(16),
                        child: Text(c.lyricsStatus,
                            textAlign: TextAlign.center,
                            style: TextStyle(color: wa(.55), fontSize: 16)),
                      ),
              );
            }
            return _window(ctx);
          },
        ),
      ),
    ]);
  }

  Widget _window(BuildContext context) {
    final idx = c.line.value;
    final n = c.lyrics.length;
    final center = idx < 0 ? 0 : idx;
    final from = math.max(0, center - 2);
    final to = math.min(n - 1, center + 3);
    final children = <Widget>[
      for (int i = from; i <= to; i++) _lineWidget(context, i, idx),
    ];
    return ClipRect(
      child: OverflowBox(
        maxHeight: double.infinity,
        alignment: Alignment.center,
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 350),
          transitionBuilder: (child, anim) => FadeTransition(
            opacity: anim,
            child: SlideTransition(
              position: Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
                  .animate(anim),
              child: child,
            ),
          ),
          child: Column(
            key: ValueKey<int>(idx),
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: children,
          ),
        ),
      ),
    );
  }

  Future<void> _editDialog(BuildContext context, int i) async {
    final ctl = TextEditingController(text: c.lyrics[i].text);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1D1D21),
        title: const Text('Исправить строку'),
        content: TextField(controller: ctl, autofocus: true, maxLines: null),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Отмена')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Сохранить')),
        ],
      ),
    );
    if (ok == true) await c.editLine(i, ctl.text);
  }

  Widget _lineWidget(BuildContext context, int i, int idx) {
    final d = idx < 0 ? i + 1 : i - idx;
    final ln = c.lyrics[i];
    final active = d == 0;
    final fs = active ? (big ? 54.0 : 28.0) : (big ? 38.0 : 20.0);
    Widget w;
    if (active) {
      w = ActiveLine(c: c, index: i, fontSize: fs);
    } else {
      final ad = d.abs();
      final o = ad == 1 ? 0.38 : (ad == 2 ? 0.2 : 0.1);
      w = ImageFiltered(
        imageFilter: ImageFilter.blur(sigmaX: ad * 1.2, sigmaY: ad * 1.2),
        child: Text(ln.text.isEmpty ? '♪' : ln.text,
            style: TextStyle(
                fontSize: fs,
                height: 1.15,
                fontWeight: FontWeight.w800,
                color: wa(o))),
      );
    }
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => c.seekToLine(i),
      onLongPress: () => _editDialog(context, i),
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: big ? 14 : 8),
        child: w,
      ),
    );
  }
}

class ActiveLine extends StatelessWidget {
  final PlayerController c;
  final int index;
  final double fontSize;
  const ActiveLine(
      {super.key, required this.c, required this.index, required this.fontSize});

  @override
  Widget build(BuildContext context) {
    final ln = c.lyrics[index];
    final n = c.lyrics.length;
    final end = index + 1 < n
        ? c.lyrics[index + 1].time
        : ln.time + const Duration(seconds: 6);
    final span = (end - ln.time).inMilliseconds;
    final win = math.min(span * 0.9, ln.words.length * 450.0 + 800.0);
    final lens = ln.words.map((w) => w.length + 1).toList();
    final total = lens.fold<int>(0, (a, b) => a + b);

    return ValueListenableBuilder<Duration>(
      valueListenable: c.pos,
      builder: (ctx, pos, _) {
        final frac = win <= 0
            ? 1.0
            : ((pos + c.offset - ln.time).inMilliseconds / win).clamp(0.0, 1.0).toDouble();
        final reached = frac * total;
        int acc = 0;
        final spans = <TextSpan>[];
        for (int k = 0; k < ln.words.length; k++) {
          final sung = reached >= acc;
          final key = ln.keys[k];
          final color = key
              ? (sung ? kRed : ca(kRed, .55))
              : (sung ? Colors.white : wa(.55));
          spans.add(TextSpan(
            text: ln.words[k] + (k < ln.words.length - 1 ? ' ' : ''),
            style: TextStyle(
              color: color,
              shadows: (key && sung)
                  ? [Shadow(color: ca(kRed, .55), blurRadius: 20)]
                  : null,
            ),
          ));
          acc += lens[k];
        }
        return Text.rich(TextSpan(
          children: spans,
          style: TextStyle(
              fontSize: fontSize, height: 1.15, fontWeight: FontWeight.w800),
        ));
      },
    );
  }
}
